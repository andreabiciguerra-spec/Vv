package com.transformers.mod.entity;

import com.transformers.mod.TransformersMod;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntityTypes {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITIES, TransformersMod.MOD_ID);

    public static final RegistryObject<EntityType<TransformerVehicleEntity>> TRANSFORMER_VEHICLE =
            ENTITIES.register("transformer_vehicle",
                    () -> EntityType.Builder.<TransformerVehicleEntity>of(TransformerVehicleEntity::new, MobCategory.MISC)
                            .sized(2.2f, 1.6f)
                            .clientTrackingRange(10)
                            .updateInterval(3)
                            .build("transformer_vehicle"));
}
