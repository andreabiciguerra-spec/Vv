package com.transformers.mod.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.transformers.mod.entity.TransformerVehicleEntity;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MinecartRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.vehicle.AbstractMinecart;

/**
 * Temporary renderer. Uses a stretched minecart-like look.
 * Replace later with a proper Blockbench / GeckoLib model of the car/robot.
 */
public class TransformerVehicleRenderer extends EntityRenderer<TransformerVehicleEntity> {

    private static final ResourceLocation TEXTURE =
            new ResourceLocation("minecraft", "textures/entity/minecart.png");

    public TransformerVehicleRenderer(EntityRendererProvider.Context ctx) {
        super(ctx);
        this.shadowRadius = 1.0F;
    }

    @Override
    public void render(TransformerVehicleEntity entity, float entityYaw, float partialTicks,
                       PoseStack poseStack, MultiBufferSource buffer, int packedLight) {
        poseStack.pushPose();
        // Scale it a bit bigger to look more like a car
        poseStack.scale(1.6f, 1.0f, 2.2f);
        // For now we just render a shadow + name. Real model comes later.
        super.render(entity, entityYaw, partialTicks, poseStack, buffer, packedLight);
        poseStack.popPose();
    }

    @Override
    public ResourceLocation getTextureLocation(TransformerVehicleEntity entity) {
        return TEXTURE;
    }
}
