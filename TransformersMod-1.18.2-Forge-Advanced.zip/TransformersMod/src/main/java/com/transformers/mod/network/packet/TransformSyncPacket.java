package com.transformers.mod.network.packet;

import com.transformers.mod.capability.PlayerTransformationProvider;
import net.minecraft.client.Minecraft;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class TransformSyncPacket {
    private final boolean transformed;
    private final int remaining;
    private final String form;

    public TransformSyncPacket(boolean transformed, int remaining, String form) {
        this.transformed = transformed;
        this.remaining = remaining;
        this.form = form;
    }

    public TransformSyncPacket(FriendlyByteBuf buf) {
        this.transformed = buf.readBoolean();
        this.remaining = buf.readInt();
        this.form = buf.readUtf();
    }

    public void encode(FriendlyByteBuf buf) {
        buf.writeBoolean(transformed);
        buf.writeInt(remaining);
        buf.writeUtf(form);
    }

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> {
                if (Minecraft.getInstance().player != null) {
                    Minecraft.getInstance().player.getCapability(PlayerTransformationProvider.PLAYER_TRANSFORMATION)
                            .ifPresent(data -> {
                                data.setTransformed(transformed);
                                data.setRemainingTicks(remaining);
                                data.setForm(form);
                            });
                }
            });
        });
        ctx.get().setPacketHandled(true);
    }
}
