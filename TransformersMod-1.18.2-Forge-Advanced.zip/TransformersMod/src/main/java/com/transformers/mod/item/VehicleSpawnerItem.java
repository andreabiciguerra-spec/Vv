package com.transformers.mod.item;

import com.transformers.mod.entity.TransformerVehicleEntity;
import com.transformers.mod.entity.ModEntityTypes;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.TextComponent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;

public class VehicleSpawnerItem extends Item {
    private final String vehicleType;

    public VehicleSpawnerItem(Properties properties, String vehicleType) {
        super(properties);
        this.vehicleType = vehicleType;
    }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        Level level = context.getLevel();
        if (level.isClientSide) return InteractionResult.SUCCESS;

        BlockPos pos = context.getClickedPos().relative(context.getClickedFace());
        if (level instanceof ServerLevel serverLevel) {
            TransformerVehicleEntity vehicle = ModEntityTypes.TRANSFORMER_VEHICLE.get()
                    .create(serverLevel, null, null, null, pos, MobSpawnType.SPAWN_EGG, true, true);

            if (vehicle != null) {
                vehicle.setVehicleType(vehicleType);
                vehicle.setYRot(context.getPlayer() != null ? context.getPlayer().getYRot() : 0);
                serverLevel.addFreshEntity(vehicle);

                if (context.getPlayer() != null) {
                    context.getPlayer().sendMessage(new TextComponent("§6§l[TRANSFORMERS] §eVehículo desplegado: §b" + vehicleType.toUpperCase()),
                            context.getPlayer().getUUID());
                }

                level.playSound(null, pos, SoundEvents.ANVIL_PLACE, SoundSource.BLOCKS, 1.0F, 0.8F);
                level.playSound(null, pos, SoundEvents.LIGHTNING_BOLT_IMPACT, SoundSource.BLOCKS, 0.6F, 1.2F);

                if (context.getPlayer() != null && !context.getPlayer().getAbilities().instabuild) {
                    context.getItemInHand().shrink(1);
                }
            }
        }
        return InteractionResult.CONSUME;
    }
}
