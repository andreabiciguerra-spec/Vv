package com.transformers.mod.client;

import com.transformers.mod.TransformersMod;
import com.transformers.mod.entity.ModEntityTypes;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.renderer.entity.EntityRenderers;
import net.minecraft.client.renderer.entity.MinecartRenderer; // temporary placeholder renderer style
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.ClientRegistry;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

@Mod.EventBusSubscriber(modid = TransformersMod.MOD_ID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
public class ClientSetup {

    public static KeyMapping TRANSFORM_KEY;

    public static void init() {
        TRANSFORM_KEY = new KeyMapping(
                "key.transformersmod.transform",
                GLFW.GLFW_KEY_R,
                "key.categories.transformersmod"
        );
        ClientRegistry.registerKeyBinding(TRANSFORM_KEY);

        // Basic entity renderer (uses a simple model for now - replace with custom later)
        EntityRenderers.register(ModEntityTypes.TRANSFORMER_VEHICLE.get(),
                ctx -> new TransformerVehicleRenderer(ctx));
    }
}
