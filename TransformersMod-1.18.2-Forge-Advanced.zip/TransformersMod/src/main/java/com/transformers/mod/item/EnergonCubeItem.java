package com.transformers.mod.item;

import com.transformers.mod.capability.PlayerTransformationProvider;
import com.transformers.mod.config.ModConfig;
import net.minecraft.network.chat.TextComponent;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public class EnergonCubeItem extends Item {

    public EnergonCubeItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);

        if (!level.isClientSide && player instanceof ServerPlayer serverPlayer) {
            // Restore some transformation time or give short boost
            serverPlayer.getCapability(PlayerTransformationProvider.PLAYER_TRANSFORMATION).ifPresent(data -> {
                if (data.isTransformed()) {
                    int add = 200; // +10s
                    data.setRemainingTicks(data.getRemainingTicks() + add);
                    serverPlayer.sendMessage(new TextComponent("§a§l+10s de transformación por Energon"), serverPlayer.getUUID());
                } else {
                    // Short boost even if not transformed
                    serverPlayer.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 200, 1));
                    serverPlayer.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 100, 1));
                    serverPlayer.sendMessage(new TextComponent("§aEnergon absorbido. Boost temporal."), serverPlayer.getUUID());
                }
            });

            level.playSound(null, player.getX(), player.getY(), player.getZ(),
                    SoundEvents.EXPERIENCE_ORB_PICKUP, SoundSource.PLAYERS, 1.0F, 0.8F);

            if (!player.getAbilities().instabuild) {
                stack.shrink(1);
            }
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }
}
