package com.transformers.mod.item;

import com.transformers.mod.capability.PlayerTransformation;
import com.transformers.mod.capability.PlayerTransformationProvider;
import com.transformers.mod.config.ModConfig;
import com.transformers.mod.network.ModMessages;
import com.transformers.mod.network.packet.TransformSyncPacket;
import net.minecraft.network.chat.TextComponent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraftforge.network.PacketDistributor;

public class TransformationCoreItem extends Item {

    public TransformationCoreItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);

        if (!level.isClientSide && player instanceof ServerPlayer serverPlayer) {
            serverPlayer.getCapability(PlayerTransformationProvider.PLAYER_TRANSFORMATION).ifPresent(data -> {
                if (data.canTransform()) {
                    int duration = ModConfig.TRANSFORM_DURATION.get();
                    data.startTransformation(duration, "robot");

                    // Effects
                    serverPlayer.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, duration, 2, false, true));
                    serverPlayer.addEffect(new MobEffectInstance(MobEffects.JUMP, duration, 1, false, true));
                    serverPlayer.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, duration, 1, false, true));
                    serverPlayer.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, duration, 0, false, false));
                    serverPlayer.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, duration, 0, false, true));

                    // Messages
                    serverPlayer.sendMessage(new TextComponent("§6§l[TRANSFORMERS] §e¡MODO ROBOT ACTIVADO!"), serverPlayer.getUUID());
                    serverPlayer.sendMessage(new TextComponent("§b« Autobots, ¡transformense y rueden! »"), serverPlayer.getUUID());
                    serverPlayer.sendMessage(new TextComponent("§7Duración: " + (duration / 20) + " segundos"), serverPlayer.getUUID());

                    // Sounds
                    if (ModConfig.SOUNDS_ENABLED.get()) {
                        level.playSound(null, player.getX(), player.getY(), player.getZ(),
                                SoundEvents.LIGHTNING_BOLT_THUNDER, SoundSource.PLAYERS, 0.7F, 1.4F);
                        level.playSound(null, player.getX(), player.getY(), player.getZ(),
                                SoundEvents.ANVIL_LAND, SoundSource.PLAYERS, 0.8F, 0.6F);
                        level.playSound(null, player.getX(), player.getY(), player.getZ(),
                                SoundEvents.BEACON_ACTIVATE, SoundSource.PLAYERS, 1.0F, 1.2F);
                    }

                    // Burst particles
                    if (level instanceof ServerLevel serverLevel && ModConfig.PARTICLES_ENABLED.get()) {
                        for (int i = 0; i < 80; i++) {
                            double ox = (level.random.nextDouble() - 0.5) * 2.5;
                            double oy = level.random.nextDouble() * 2.2;
                            double oz = (level.random.nextDouble() - 0.5) * 2.5;
                            serverLevel.sendParticles(ParticleTypes.ELECTRIC_SPARK,
                                    player.getX() + ox, player.getY() + oy, player.getZ() + oz, 1, 0, 0, 0, 0.15);
                            serverLevel.sendParticles(ParticleTypes.END_ROD,
                                    player.getX() + ox, player.getY() + oy, player.getZ() + oz, 1, 0, 0, 0, 0.08);
                            serverLevel.sendParticles(ParticleTypes.FLASH,
                                    player.getX(), player.getY() + 1, player.getZ(), 1, 0, 0, 0, 0);
                        }
                    }

                    // Sync to client
                    ModMessages.INSTANCE.send(PacketDistributor.PLAYER.with(() -> serverPlayer),
                            new TransformSyncPacket(true, duration, "robot"));

                    player.getCooldowns().addCooldown(this, 40); // short item cooldown, real CD is capability
                } else {
                    if (data.isTransformed()) {
                        serverPlayer.sendMessage(new TextComponent("§cYa estás transformado. Tiempo restante: " +
                                (data.getRemainingTicks() / 20) + "s"), serverPlayer.getUUID());
                    } else {
                        serverPlayer.sendMessage(new TextComponent("§cEnfriamiento activo: " +
                                (data.getCooldownTicks() / 20) + "s restantes"), serverPlayer.getUUID());
                    }
                }
            });
        }

        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }
}
