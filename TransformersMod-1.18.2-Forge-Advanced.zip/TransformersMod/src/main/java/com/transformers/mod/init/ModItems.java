package com.transformers.mod.init;

import com.transformers.mod.TransformersMod;
import com.transformers.mod.item.EnergonCubeItem;
import com.transformers.mod.item.TransformationCoreItem;
import com.transformers.mod.item.VehicleSpawnerItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, TransformersMod.MOD_ID);

    public static final CreativeModeTab TRANSFORMERS_TAB = new CreativeModeTab("transformersmod") {
        @Override
        public ItemStack makeIcon() {
            return new ItemStack(TRANSFORMATION_CORE.get());
        }
    };

    // Core items
    public static final RegistryObject<Item> TRANSFORMATION_CORE = ITEMS.register("transformation_core",
            () -> new TransformationCoreItem(new Item.Properties().tab(TRANSFORMERS_TAB).stacksTo(1)));

    public static final RegistryObject<Item> ENERGON_CUBE = ITEMS.register("energon_cube",
            () -> new EnergonCubeItem(new Item.Properties().tab(TRANSFORMERS_TAB).stacksTo(16)));

    public static final RegistryObject<Item> ALLSPARK_FRAGMENT = ITEMS.register("allspark_fragment",
            () -> new Item(new Item.Properties().tab(TRANSFORMERS_TAB).stacksTo(1).fireResistant()));

    // Vehicle spawners (inspired by the concept art)
    public static final RegistryObject<Item> BARRICADE_SPAWNER = ITEMS.register("barricade_spawner",
            () -> new VehicleSpawnerItem(new Item.Properties().tab(TRANSFORMERS_TAB).stacksTo(1), "barricade"));

    public static final RegistryObject<Item> BLUE_AUTOBOT_SPAWNER = ITEMS.register("blue_autobot_spawner",
            () -> new VehicleSpawnerItem(new Item.Properties().tab(TRANSFORMERS_TAB).stacksTo(1), "blue_autobot"));
}
