package com.transformers.mod.event;

import com.transformers.mod.capability.PlayerTransformationProvider;
import com.transformers.mod.config.ModConfig;
import com.transformers.mod.network.ModMessages;
import com.transformers.mod.network.packet.TransformSyncPacket;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.network.PacketDistributor;

public class ModEvents {

    @SubscribeEvent
    public void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Player player = event.player;

        player.getCapability(PlayerTransformationProvider.PLAYER_TRANSFORMATION).ifPresent(data -> {
            boolean wasTransformed = data.isTransformed();
            data.tick();

            // Just ended transformation
            if (wasTransformed && !data.isTransformed()) {
                data.endTransformation(ModConfig.TRANSFORM_COOLDOWN.get());
                if (!player.level.isClientSide && player instanceof ServerPlayer sp) {
                    sp.sendMessage(new net.minecraft.network.chat.TextComponent(
                            "§c§l[TRANSFORMERS] §eTransformación finalizada. Enfriamiento activo."), sp.getUUID());
                    ModMessages.INSTANCE.send(PacketDistributor.PLAYER.with(() -> sp),
                            new TransformSyncPacket(false, 0, "none"));
                }
            }

            // Continuous particles while transformed (server)
            if (data.isTransformed() && !player.level.isClientSide && ModConfig.PARTICLES_ENABLED.get()) {
                if (player.tickCount % 4 == 0 && player.level instanceof ServerLevel serverLevel) {
                    serverLevel.sendParticles(ParticleTypes.ELECTRIC_SPARK,
                            player.getX() + (player.level.random.nextDouble() - 0.5) * 0.8,
                            player.getY() + 1.0 + player.level.random.nextDouble() * 0.6,
                            player.getZ() + (player.level.random.nextDouble() - 0.5) * 0.8,
                            2, 0, 0.05, 0, 0.02);
                }
            }
        });
    }

    @SubscribeEvent
    public void onPlayerLoggedIn(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getPlayer() instanceof ServerPlayer sp) {
            sp.getCapability(PlayerTransformationProvider.PLAYER_TRANSFORMATION).ifPresent(data -> {
                ModMessages.INSTANCE.send(PacketDistributor.PLAYER.with(() -> sp),
                        new TransformSyncPacket(data.isTransformed(), data.getRemainingTicks(), data.getForm()));
            });
        }
    }
}
