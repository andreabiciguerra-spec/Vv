package com.transformers.mod.config;

import net.minecraftforge.common.ForgeConfigSpec;

public class ModConfig {
    public static final ForgeConfigSpec.Builder BUILDER = new ForgeConfigSpec.Builder();
    public static final ForgeConfigSpec SPEC;

    public static final ForgeConfigSpec.IntValue TRANSFORM_DURATION;
    public static final ForgeConfigSpec.IntValue TRANSFORM_COOLDOWN;
    public static final ForgeConfigSpec.DoubleValue ROBOT_SPEED_MULTIPLIER;
    public static final ForgeConfigSpec.DoubleValue ROBOT_JUMP_MULTIPLIER;
    public static final ForgeConfigSpec.BooleanValue PARTICLES_ENABLED;
    public static final ForgeConfigSpec.BooleanValue SOUNDS_ENABLED;

    static {
        BUILDER.push("Transformation Settings");

        TRANSFORM_DURATION = BUILDER
                .comment("Duration of transformation in ticks (20 ticks = 1 second). Default 600 = 30s")
                .defineInRange("transformDuration", 600, 100, 72000);

        TRANSFORM_COOLDOWN = BUILDER
                .comment("Cooldown after transformation ends (ticks). Default 200 = 10s")
                .defineInRange("transformCooldown", 200, 0, 72000);

        ROBOT_SPEED_MULTIPLIER = BUILDER
                .comment("Speed multiplier while transformed")
                .defineInRange("robotSpeedMultiplier", 1.6, 1.0, 3.0);

        ROBOT_JUMP_MULTIPLIER = BUILDER
                .comment("Jump strength multiplier while transformed")
                .defineInRange("robotJumpMultiplier", 1.4, 1.0, 3.0);

        PARTICLES_ENABLED = BUILDER
                .comment("Enable continuous particles while transformed")
                .define("particlesEnabled", true);

        SOUNDS_ENABLED = BUILDER
                .comment("Enable transformation sounds")
                .define("soundsEnabled", true);

        BUILDER.pop();
        SPEC = BUILDER.build();
    }
}
