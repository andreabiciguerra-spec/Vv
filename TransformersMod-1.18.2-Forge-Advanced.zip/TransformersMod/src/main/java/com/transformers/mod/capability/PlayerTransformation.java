package com.transformers.mod.capability;

import net.minecraft.nbt.CompoundTag;

public class PlayerTransformation {
    private boolean transformed = false;
    private int remainingTicks = 0;
    private int cooldownTicks = 0;
    private String form = "none"; // "robot", "car", "none"

    public boolean isTransformed() {
        return transformed;
    }

    public void setTransformed(boolean transformed) {
        this.transformed = transformed;
    }

    public int getRemainingTicks() {
        return remainingTicks;
    }

    public void setRemainingTicks(int remainingTicks) {
        this.remainingTicks = remainingTicks;
    }

    public int getCooldownTicks() {
        return cooldownTicks;
    }

    public void setCooldownTicks(int cooldownTicks) {
        this.cooldownTicks = cooldownTicks;
    }

    public String getForm() {
        return form;
    }

    public void setForm(String form) {
        this.form = form;
    }

    public void tick() {
        if (transformed && remainingTicks > 0) {
            remainingTicks--;
            if (remainingTicks <= 0) {
                transformed = false;
                form = "none";
            }
        }
        if (cooldownTicks > 0) {
            cooldownTicks--;
        }
    }

    public boolean canTransform() {
        return !transformed && cooldownTicks <= 0;
    }

    public void startTransformation(int duration, String form) {
        this.transformed = true;
        this.remainingTicks = duration;
        this.form = form;
    }

    public void endTransformation(int cooldown) {
        this.transformed = false;
        this.remainingTicks = 0;
        this.form = "none";
        this.cooldownTicks = cooldown;
    }

    public void saveNBT(CompoundTag tag) {
        tag.putBoolean("Transformed", transformed);
        tag.putInt("Remaining", remainingTicks);
        tag.putInt("Cooldown", cooldownTicks);
        tag.putString("Form", form);
    }

    public void loadNBT(CompoundTag tag) {
        transformed = tag.getBoolean("Transformed");
        remainingTicks = tag.getInt("Remaining");
        cooldownTicks = tag.getInt("Cooldown");
        form = tag.contains("Form") ? tag.getString("Form") : "none";
    }

    public CompoundTag serializeNBT() {
        CompoundTag tag = new CompoundTag();
        saveNBT(tag);
        return tag;
    }

    public void deserializeNBT(CompoundTag tag) {
        loadNBT(tag);
    }
}
