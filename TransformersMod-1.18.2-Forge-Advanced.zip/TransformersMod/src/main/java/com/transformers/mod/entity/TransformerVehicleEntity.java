package com.transformers.mod.entity;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.NetworkHooks;

import javax.annotation.Nullable;

/**
 * Rideable Transformer vehicle (car mode).
 * Inspired by Barricade / Blue Autobot concept art.
 * Right-click to mount. Sneak + right-click or jump off to dismount.
 */
public class TransformerVehicleEntity extends Entity {

    private static final EntityDataAccessor<String> DATA_TYPE =
            SynchedEntityData.defineId(TransformerVehicleEntity.class, EntityDataSerializers.STRING);

    private float speed = 0.35f;
    private int life = 0;

    public TransformerVehicleEntity(EntityType<? extends TransformerVehicleEntity> type, Level level) {
        super(type, level);
        this.blocksBuilding = true;
    }

    @Override
    protected void defineSynchedData() {
        this.entityData.define(DATA_TYPE, "barricade");
    }

    public void setVehicleType(String type) {
        this.entityData.set(DATA_TYPE, type);
    }

    public String getVehicleType() {
        return this.entityData.get(DATA_TYPE);
    }

    @Override
    public Packet<?> getAddEntityPacket() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }

    @Override
    public boolean isPickable() {
        return !this.isRemoved();
    }

    @Override
    public boolean canBeCollidedWith() {
        return true;
    }

    @Override
    public boolean isPushable() {
        return true;
    }

    @Override
    public InteractionResult interact(Player player, InteractionHand hand) {
        if (!this.level.isClientSide && !player.isSecondaryUseActive()) {
            if (this.getPassengers().isEmpty()) {
                player.startRiding(this);
                this.level.playSound(null, this.getX(), this.getY(), this.getZ(),
                        SoundEvents.MINECART_RIDING, SoundSource.NEUTRAL, 0.6F, 1.0F);
                return InteractionResult.CONSUME;
            }
        }
        return InteractionResult.PASS;
    }

    @Override
    public void tick() {
        super.tick();
        life++;

        if (!this.level.isClientSide) {
            this.setDeltaMovement(this.getDeltaMovement().multiply(0.95, 1.0, 0.95));

            if (this.getPassengers().isEmpty()) {
                // idle slight bobble or just sit
            } else {
                Entity controller = this.getControllingPassenger();
                if (controller instanceof Player player) {
                    // Steering
                    float yaw = player.getYRot();
                    this.setYRot(yaw);
                    this.yRotO = this.getYRot();

                    // Forward / back
                    float forward = player.zza;
                    float strafe = player.xxa * 0.3f;

                    if (Math.abs(forward) > 0.01 || Math.abs(strafe) > 0.01) {
                        Vec3 motion = this.getDeltaMovement();
                        double speedMul = player.isSprinting() ? 1.6 : 1.0;
                        double mx = -Mth.sin(yaw * ((float) Math.PI / 180F)) * forward * speed * speedMul
                                + Mth.cos(yaw * ((float) Math.PI / 180F)) * strafe * speed;
                        double mz = Mth.cos(yaw * ((float) Math.PI / 180F)) * forward * speed * speedMul
                                + Mth.sin(yaw * ((float) Math.PI / 180F)) * strafe * speed;

                        this.setDeltaMovement(mx, motion.y, mz);
                    }

                    // Jump / boost
                    if (player.jumping && this.isOnGround()) {
                        this.setDeltaMovement(this.getDeltaMovement().add(0, 0.45, 0));
                        this.level.playSound(null, this.getX(), this.getY(), this.getZ(),
                                SoundEvents.PISTON_EXTEND, SoundSource.NEUTRAL, 0.4F, 1.5F);
                    }
                }
            }

            this.move(MoverType.SELF, this.getDeltaMovement());

            // Simple ground check
            if (this.isOnGround()) {
                this.setDeltaMovement(this.getDeltaMovement().multiply(0.9, 0, 0.9));
            } else {
                this.setDeltaMovement(this.getDeltaMovement().add(0, -0.04, 0));
            }
        } else {
            // Client side visual spin or whatever later
        }
    }

    @Nullable
    @Override
    public Entity getControllingPassenger() {
        return this.getPassengers().isEmpty() ? null : this.getPassengers().get(0);
    }

    @Override
    public boolean causeFallDamage(float fallDistance, float multiplier, DamageSource source) {
        return false; // transformers don't take fall damage easily
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
        if (tag.contains("VehicleType")) {
            setVehicleType(tag.getString("VehicleType"));
        }
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
        tag.putString("VehicleType", getVehicleType());
    }

    @Override
    public double getPassengersRidingOffset() {
        return 0.6D;
    }
}
