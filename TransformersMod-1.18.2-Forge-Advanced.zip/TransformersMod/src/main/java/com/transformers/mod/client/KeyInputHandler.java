package com.transformers.mod.client;

import com.transformers.mod.capability.PlayerTransformationProvider;
import com.transformers.mod.item.TransformationCoreItem;
import com.transformers.mod.init.ModItems;
import net.minecraft.client.Minecraft;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = "transformersmod", value = Dist.CLIENT)
public class KeyInputHandler {

    @SubscribeEvent
    public static void onKeyInput(InputEvent.KeyInputEvent event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.screen != null) return;

        if (ClientSetup.TRANSFORM_KEY != null && ClientSetup.TRANSFORM_KEY.consumeClick()) {
            // Try to use Transformation Core from inventory or offhand/mainhand
            ItemStack main = mc.player.getMainHandItem();
            ItemStack off = mc.player.getOffhandItem();

            if (main.getItem() instanceof TransformationCoreItem) {
                mc.gameMode.useItem(mc.player, mc.level, InteractionHand.MAIN_HAND);
            } else if (off.getItem() instanceof TransformationCoreItem) {
                mc.gameMode.useItem(mc.player, mc.level, InteractionHand.OFF_HAND);
            } else {
                // Search hotbar quickly
                for (int i = 0; i < 9; i++) {
                    ItemStack stack = mc.player.getInventory().getItem(i);
                    if (stack.getItem() instanceof TransformationCoreItem) {
                        // Just message for now - full auto-use needs more packets
                        mc.player.displayClientMessage(
                                new net.minecraft.network.chat.TextComponent(
                                        "§eTenés el Núcleo de Transformación. Usalo (clic derecho) o ponelo en la mano y pulsa R"),
                                true);
                        break;
                    }
                }
            }
        }
    }
}
