package com.transformers.mod.network;

import com.transformers.mod.TransformersMod;
import com.transformers.mod.network.packet.TransformSyncPacket;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

public class ModMessages {
    private static final String PROTOCOL = "1";
    public static final SimpleChannel INSTANCE = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(TransformersMod.MOD_ID, "main"),
            () -> PROTOCOL,
            PROTOCOL::equals,
            PROTOCOL::equals
    );

    private static int id = 0;

    public static void register() {
        INSTANCE.registerMessage(id++, TransformSyncPacket.class,
                TransformSyncPacket::encode,
                TransformSyncPacket::new,
                TransformSyncPacket::handle);
    }
}
