# Transformers Mod — Minecraft 1.18.2 Forge

**¡Autobots, transformense y rueden!**

Mod bastante completo (template avanzado) para **Minecraft Java 1.18.2 + Forge 40.3.11 / 40.3.12**.

## Características incluidas

### Sistema de Transformación
- **Núcleo de Transformación**: Clic derecho o tecla **R** (con el item en la mano)
- Activa **Modo Robot** durante 30 segundos (configurable):
  - Velocidad III + Salto II + Resistencia II + Fuerza + Visión nocturna
  - Partículas eléctricas continuas
  - Sonidos épicos de transformación
  - Cooldown real guardado en capability del jugador (persiste entre logins)
- **Cubo de Energon**: Extiende la transformación +10s o da boost temporal
- **Fragmento del AllSpark**: Item especial (placeholder para futuras features)

### Vehículos
- **Desplegador de Barricade** (inspirado en el auto policial de las imágenes)
- **Desplegador Autobot Azul** (inspirado en el robot + auto azul + helicóptero)
- Vehículos **rideables**: clic derecho para montar, WASD + Sprint + Salto
- Hitbox y física básica de auto

### Otros
- Creative Tab propia “Transformers”
- Configuración en `transformersmod-common.toml` (duración, cooldown, partículas, sonidos…)
- Keybind personalizable (R por defecto)
- Recetas de crafteo
- Advancement raíz
- Soporte español + inglés
- Concept art original incluido en `/docs`

## Requisitos
- Java **17**
- Minecraft **1.18.2**
- Forge **40.3.11** o **40.3.12**

## Cómo compilar

```bash
# 1. Extrae el ZIP
# 2. Abre la carpeta en IntelliJ IDEA (recomendado) o usa terminal:

cd TransformersMod
./gradlew build
```

El JAR queda en:
```
build/libs/transformersmod-1.0.0.jar
```

Cópialo a tu carpeta `mods`.

## Controles en el juego
- **Clic derecho** con el Núcleo → Transformar
- **Tecla R** → Intenta activar el Núcleo (si lo tenés en la mano)
- **Clic derecho** en el suelo con un Desplegador → Spawnea el vehículo
- **Clic derecho** en el vehículo → Montar
- **Shift** (o desmontar normal) → Bajar

## Ideas futuras / cómo expandir (mis recomendaciones)

1. **Modelos reales**: Usa Blockbench + exporta a `.json` o usa **GeckoLib** para animaciones de transformación auto ↔ robot.
2. **GeckoLib** (recomendado):
   ```gradle
   implementation fg.deobf("software.bernie.geckolib:geckolib-forge-1.18:3.0.57")
   ```
3. Añadir más formas: helicóptero, camión, etc. (las imágenes que pasaste son perfectas de referencia).
4. Sistema de Energon como “combustible” real del vehículo.
5. Armas / habilidades en modo robot (disparo de energía, etc.).
6. Skin / overlay del jugador mientras está transformado.

## Estructura importante
```
src/main/java/com/transformers/mod/
├── TransformersMod.java          ← Entry point
├── capability/                   ← Estado de transformación del jugador
├── client/                       ← Keybinds + Renderer del vehículo
├── config/                       ← Config Toml
├── entity/                       ← TransformerVehicleEntity
├── event/                        ← Tick, login sync
├── init/                         ← Items
├── item/                         ← Lógica de los items
└── network/                      ← Packets de sincronización
```

## Créditos de las imágenes
Las imágenes de concepto (Barricade estilo policía, robot azul + auto + helicóptero) están en la carpeta `docs/` y fueron proporcionadas por el usuario.

---

Hecho con cariño para que puedas seguir construyendo el mod de Transformers que querés.  
Si necesitás que agregue GeckoLib ya configurado, más entidades, HUD de transformación, o cualquier otra cosa… solo decime.
